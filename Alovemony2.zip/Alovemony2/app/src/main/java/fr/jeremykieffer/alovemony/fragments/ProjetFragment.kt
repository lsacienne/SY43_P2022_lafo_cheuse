package fr.jeremykieffer.alovemony.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import fr.jeremykieffer.alovemony.MainActivity
import fr.jeremykieffer.alovemony.ProjetModel
import fr.jeremykieffer.alovemony.ProjetRepository.Singleton.projetList
import fr.jeremykieffer.alovemony.R
import fr.jeremykieffer.alovemony.adapter.ProjetAdapter
import fr.jeremykieffer.alovemony.adapter.ProjetItemDecoration

class ProjetFragment(
    private val context: MainActivity
) : Fragment(){

    // appele onCreateView lors de la création du HomeFragment qui injecte fragment_home sur la page //
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater?.inflate(R.layout.fragment_projet, container, false)

        //recuperer le recyclerview horizontal
        val horizontalRecyclerView = view.findViewById<RecyclerView>(R.id.horizontal_recycler_view)
        horizontalRecyclerView.adapter = ProjetAdapter(context, projetList, R.layout.item_horizontal_projet)

        //recuperer le recyclerview vertical
        val verticalRecyclerView = view.findViewById<RecyclerView>(R.id.vertical_recycler_view)
        verticalRecyclerView.adapter = ProjetAdapter(context, projetList, R.layout.item_vertical_projet)
        verticalRecyclerView.addItemDecoration(ProjetItemDecoration())

        return view
    }
}