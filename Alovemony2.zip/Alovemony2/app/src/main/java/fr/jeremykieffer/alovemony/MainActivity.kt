package fr.jeremykieffer.alovemony

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import fr.jeremykieffer.alovemony.fragments.DepenseFragment
import fr.jeremykieffer.alovemony.fragments.ProjetFragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // charger notre ProjetRepository
        val repo_projet = ProjetRepository()

        // charger notre DepenseRepository
        val repo_depense = DepenseRepository()


        // mettre à jour la liste des projets
        repo_projet.updateData() {
            //injecter le fragment dans notre boite (fragment_container)
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, ProjetFragment(this))
            transaction.addToBackStack(null)
            transaction.commit()
        }


        // mettre à jour la liste des depenses
        repo_depense.updateData() {
            //injecter le fragment dans notre boite (fragment_container)
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, DepenseFragment(this))
            transaction.addToBackStack(null)
            transaction.commit()
        }




    }
}