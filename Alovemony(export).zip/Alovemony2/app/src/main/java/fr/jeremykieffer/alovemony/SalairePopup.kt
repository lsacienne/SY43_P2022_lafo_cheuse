package fr.jeremykieffer.alovemony

import android.app.Dialog
import android.os.Bundle
import android.view.Window
import android.widget.Button
import fr.jeremykieffer.alovemony.adapter.AccueilAdapter

class SalairePopup(private val adapter:AccueilAdapter) : Dialog(adapter.context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.fragment_salaire)
        setupNextButton()
        setupPreviousButton()
    }
    private fun setupNextButton() {
        findViewById<Button>(R.id.salaire_finish_btn).setOnClickListener {
            PrelevementPopup(adapter).show()
            dismiss()
        }
    }
    private fun setupPreviousButton() {
        findViewById<Button>(R.id.salaire_return_btn).setOnClickListener {
            AccountPopup(adapter).show()
            dismiss()
        }
    }
}