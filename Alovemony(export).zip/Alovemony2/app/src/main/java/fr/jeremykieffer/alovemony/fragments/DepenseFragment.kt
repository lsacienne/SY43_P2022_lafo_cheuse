package fr.jeremykieffer.alovemony.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import fr.jeremykieffer.alovemony.DepenseRepository.Singleton.depenseList
import fr.jeremykieffer.alovemony.MainActivity
import fr.jeremykieffer.alovemony.ProjetRepository
import fr.jeremykieffer.alovemony.ProjetRepository.Singleton.projetList
import fr.jeremykieffer.alovemony.R
import fr.jeremykieffer.alovemony.adapter.DepenseAdapter
import fr.jeremykieffer.alovemony.adapter.ProjetAdapter
import fr.jeremykieffer.alovemony.adapter.ProjetItemDecoration

class DepenseFragment(
    private val context: MainActivity
) : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater?.inflate(R.layout.fragment_depense, container, false)

        //recuperer le recyclerview verticale
        val depenseRecyclerView = view.findViewById<RecyclerView>(R.id.depense_recycler_list)
        depenseRecyclerView.adapter = DepenseAdapter(context, depenseList, R.layout.item_vertical_projet)
        depenseRecyclerView.layoutManager = LinearLayoutManager(context)
        depenseRecyclerView.addItemDecoration(ProjetItemDecoration())

        return view
    }
}