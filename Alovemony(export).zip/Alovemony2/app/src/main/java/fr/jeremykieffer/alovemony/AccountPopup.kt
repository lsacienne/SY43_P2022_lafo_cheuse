package fr.jeremykieffer.alovemony

import android.app.Dialog
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import fr.jeremykieffer.alovemony.adapter.AccueilAdapter
import fr.jeremykieffer.alovemony.adapter.ProjetAdapter

class AccountPopup(private val adapter: AccueilAdapter) : Dialog(adapter.context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.fragment_account)
        setupNextButton()
    }

    private fun setupNextButton() {
        findViewById<Button>(R.id.account_next_button).setOnClickListener {
            SalairePopup(adapter).show()
            dismiss()
        }
    }

}