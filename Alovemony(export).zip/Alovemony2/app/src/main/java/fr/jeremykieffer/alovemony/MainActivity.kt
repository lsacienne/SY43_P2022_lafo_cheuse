package fr.jeremykieffer.alovemony

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import fr.jeremykieffer.alovemony.adapter.AccueilAdapter
import fr.jeremykieffer.alovemony.fragments.AccueilFragment
import fr.jeremykieffer.alovemony.fragments.DepenseFragment
import fr.jeremykieffer.alovemony.fragments.ProjetFragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Charger le fragment d'acceuil dans la main activity
        loadFragment(AccueilFragment(this),R.string.page_accueil_titre)

        //charger la popup settings des l'ouverture
        AccountPopup(AccueilAdapter(this,R.layout.fragment_accueil)).show()

        //importer SettingBtn
        val settingsBtn=findViewById<ImageButton>(R.id.settingsBtn)

        //Display les settings on click
        settingsBtn.setOnClickListener {
            AccountPopup(AccueilAdapter(this,R.layout.fragment_accueil)).show()
        }

        //importer la bottom nav view
        val navigationView=findViewById<BottomNavigationView>(R.id.navigation_view)
        navigationView.setOnNavigationItemSelectedListener {
            when(it.itemId)
            {
                R.id.home_page->{
                    loadFragment(AccueilFragment(this),R.string.page_accueil_titre)
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.projet_page->{
                    loadFragment(ProjetFragment(this),R.string.page_projet_titre)
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.depense_page->{
                    loadFragment(DepenseFragment(this),R.string.page_depense_titre)
                    return@setOnNavigationItemSelectedListener true

                }
                else -> false
            }
        }



    }

    private fun loadFragment(fragment: Fragment,string:Int) {

        // charger notre ProjetRepository
        val repo_projet = ProjetRepository()

// charger notre DepenseRepository
        val repo_depense = DepenseRepository()

    //actualiser le titre de la page
        findViewById<TextView>(R.id.page_title).text=resources.getString(string)
// mettre à jour la liste des projets
        repo_projet.updateData() {
            //injecter le fragment dans notre boite (fragment_container)
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container,fragment)
            transaction.addToBackStack(null)
            transaction.commit()
        }


// mettre à jour la liste des depenses
        repo_depense.updateData() {
            //injecter le fragment dans notre boite (fragment_container)
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, fragment)
            transaction.addToBackStack(null)
            transaction.commit()
        }


    }
}