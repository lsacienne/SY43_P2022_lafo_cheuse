package fr.jeremykieffer.alovemony.adapter

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import fr.jeremykieffer.alovemony.*

class AccueilAdapter(
    val context: MainActivity,
    val layoutId : Int
) : RecyclerView.Adapter<AccueilAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val depenseImage = view.findViewById<ImageView>(R.id.image_item)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AccueilAdapter.ViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(layoutId, parent, false)

        return AccueilAdapter.ViewHolder(view)
    }

    override fun onBindViewHolder(holder: AccueilAdapter.ViewHolder, position: Int) {
        // recuperer les informations de la depense
        holder.itemView.setOnClickListener {
            //afficher la popup
            AccountPopup(this).show()
        }
    }

    override fun getItemCount(): Int = 1


}


