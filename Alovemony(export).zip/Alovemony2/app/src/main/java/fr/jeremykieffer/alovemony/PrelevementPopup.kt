package fr.jeremykieffer.alovemony
import android.app.Dialog
import android.os.Bundle
import android.view.Window
import android.widget.Button
import fr.jeremykieffer.alovemony.adapter.AccueilAdapter
import fr.jeremykieffer.alovemony.adapter.ProjetAdapter

class PrelevementPopup(private val adapter:AccueilAdapter) : Dialog(adapter.context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.fragment_prelevements)
        setupPreviousButton()
        setupFinishButton()
    }

    private fun setupFinishButton() {
        findViewById<Button>(R.id.prelevement_finish_btn).setOnClickListener{
            dismiss()
        }
    }

    private fun setupPreviousButton() {
        findViewById<Button>(R.id.prelevement_return_btn).setOnClickListener {
            SalairePopup(adapter).show()
            dismiss()
        }
    }
}